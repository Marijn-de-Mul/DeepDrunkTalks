import{r as e}from"./index-Ci9peQGz.js";const o=typeof document<"u"?e.useLayoutEffect:e.useEffect;export{o as u};
