import{r as o,j as s}from"./index-Ci9peQGz.js";function c(e=null){const t=o.createContext(e);return[({children:n,value:r})=>s.jsx(t.Provider,{value:r,children:n}),()=>o.useContext(t)]}export{c};
